import pyneuralnet.models

import os
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import torchvision.utils as vutils
import torch
import torch.nn as nn
import torch.optim as optim

import pyneuralnet.models.test

def train(metadata_file, root_dir):
    class SuperResolutionDataset(Dataset):
        def __init__(self, metadata_file, root_dir, transform=None):
            with open(metadata_file, 'r') as file:
                self.image_paths = file.readlines()
            self.image_paths = [os.path.join(root_dir, path.strip()) for path in self.image_paths]
            self.transform = transform
            print(f"Loaded {len(self.image_paths)} images")
            print(f"Example path: {self.image_paths[0]}")

        def __len__(self):
            return len(self.image_paths)

        def __getitem__(self, idx):
            img_path = self.image_paths[idx]
            if not os.path.exists(img_path):
                print(f"File not found: {img_path}")
            img = Image.open(img_path).convert('RGB')
            if self.transform:
                img = self.transform(img)
            return img

    # Define transforms
    transform = transforms.Compose([
        transforms.Resize((1280, 720)),  # Resize images if necessary
        transforms.ToTensor(),          # Convert images to tensors
    ])

    # Create dataset and dataloader
    metadata_file = metadata_file
    root_dir = root_dir

    dataset = SuperResolutionDataset(metadata_file=metadata_file, root_dir=root_dir, transform=transform)
    print(f"Dataset length: {len(dataset)}")

    # Load one image to test
    try:
        sample_img = dataset[0]
        print(f"Sample image size: {sample_img.size()}")
    except FileNotFoundError as e:
        print(e)

    # Create DataLoader and Iterate
    dataloader = DataLoader(dataset, batch_size=16, shuffle=True)

    # Define loss and optimizer
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    # Check for GPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    if torch.device("cuda"):
        current_device = torch.cuda.current_device()
        print("Current GPU device:", current_device)

    # Initialize the model
    model = pyneuralnet.models.test.SRCNN

    # Train the Model
    print("Training Started")
    num_epochs = 50

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        
        for batch_idx, inputs in enumerate(dataloader):
            inputs = inputs.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, inputs)  # Since it's an autoencoder, target is input
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

            # Print batch progress
            if batch_idx % 10 == 0:
                print(f'Epoch {epoch+1}/{num_epochs}, Batch {batch_idx}/{len(dataloader)}, Loss: {loss.item()}')
        
        # Print epoch progress
        print(f'Epoch {epoch+1}/{num_epochs}, Average Loss: {running_loss/len(dataloader)}')

    # Save the model
    torch.save(model.state_dict(), 'super_resolution_model.pth')
    print("saved model")


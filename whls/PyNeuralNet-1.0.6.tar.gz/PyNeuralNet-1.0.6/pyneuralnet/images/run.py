import subprocess

def main():
    command = ["python", "train.py"] #["pip", "show", "pyneuralnet"]
    subprocess.run(command)

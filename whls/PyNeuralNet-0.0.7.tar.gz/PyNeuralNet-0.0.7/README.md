PyNeuralNet 
============

PyNeuralNet is a python library for prototyping and building neural networks. PyNeuralNet uses PyTorch as a computational backend for deep learning models.

## Installation
------------
    pip install pyneuralnet

## User Guide
----------
